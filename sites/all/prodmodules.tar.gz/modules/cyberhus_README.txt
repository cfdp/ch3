This is the Cyberhus readme file

All custom module override is put in the custom folder so we dont risk deleting them when updating drupal.

List:

quicktabs.