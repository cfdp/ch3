<?php
?>
<div class="panels-dashboard clearfix">
  <div class="dashboard-left clearfix">
    <?php print $left; ?>
  </div>

  <div class="dashboard-right clearfix">
    <?php print $right; ?>
  </div>
</div>
